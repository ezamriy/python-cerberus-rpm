.. _api:

API Documentation
=================

.. _validator:

Validator Class
---------------

.. autoclass:: cerberus.Validator
  :members:

Exceptions
----------
.. autoclass:: cerberus.SchemaError
  :members:

.. autoclass:: cerberus.ValidationError
  :members:


