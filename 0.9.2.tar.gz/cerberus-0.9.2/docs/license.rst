.. _license:
  
License
=======
Cerberus is an open source project by `Nicola Iarocci
<http://nicolaiarocci.com>`_. 

.. include:: ../LICENSE
